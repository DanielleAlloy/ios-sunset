//
//  GlobalConstants.swift

//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import Foundation

class GlobalConstants {
    // API key for Flickr
    struct APIKey {
        static let appId = "Ph1oO1unJ1n1JboqR6tI"
        static let appCode = "L-YfyYgUy3bRhrg7CSmSog"

    }
    
}
